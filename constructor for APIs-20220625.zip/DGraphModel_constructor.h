#ifndef DGRAPHMODEL_H
#define DGRAPHMODEL_H
#include "graph/AbstractGraph.h"
#include "stacknqueue/Queue.h"
#include "stacknqueue/Stack.h"
#include "hash/XHashMap.h"
#include "stacknqueue/PriorityQueue.h"
#include "sorting/DLinkedListSE.h"


//////////////////////////////////////////////////////////////////////
///////////// GraphModel: Directed Graph Model    ////////////////////
//////////////////////////////////////////////////////////////////////


template<class T>
//class AbstractGraph: public IGraph<T>{
class DGraphModel: public AbstractGraph<T>{
private:
public:
    DGraphModel(
            bool (*vertexEQ)(T&, T&), 
            string (*vertex2str)(T&) ): 
        AbstractGraph<T>(vertexEQ, vertex2str){}
        //    AbstractGraph(bool (*vertexEQ)(T&, T&)=0,string (*vertex2str)(T&)=0)
        //{
        //        this->vertexEQ = vertexEQ;
        //        this->vertex2str = vertex2str;
        //}
};

#endif /* DGRAPHMODEL_H */

